---
name: quellen-pruefdokument
description: "Nutze diesen Skill, wenn ein Rechercheergebnis oder ein vorhandener Text als Pruefdokument ausgegeben werden soll: Text mit [Q]-Markern, Tab Quellenpruefung, Quellenverzeichnis und Dokumentation in Claude Docs, besonders fuer die oeffentliche Verwaltung. Ausloeser: Pruefdokument, Quellenpruefung, Quellen pruefen, Belege pruefen, Faktencheck eines Textes, Uebergabe aus research-prompt-forge (Option A)."
license: MIT
metadata:
  version: '1.0'
---

# Quellen-Pruefdokument

Dieser Skill macht ein Rechercheergebnis oder einen vorhandenen Text pruefbar. Er erstellt ein Dokument in Claude Docs mit vier Tabs: das Ergebnis mit nummerierten Belegmarkern, eine Tabelle zur Quellenpruefung, ein Quellenverzeichnis und eine Dokumentation fuer die Akte.

Grundsatz: Die KI bereitet die Pruefung vor. Ob eine Aussage belegt ist, entscheidet ein Mensch. Das ist die menschliche Aufsicht im Sinne des EU AI Act und der Dienstanweisung, sichtbar gemacht im Dokument selbst.

## Sprach- und Dialogregeln

- Antworte in der Sprache des Nutzers (Standard: Deutsch), sprich den Nutzer mit "du" an.
- Stelle immer nur eine Frage gleichzeitig.
- Frage nichts, was aus dem Gespraech schon klar ist (z. B. aus einem vorher mit research-prompt-forge gebauten Prompt).

## Schritt 1 — Modus erkennen

- **Modus R (Recherche ausfuehren):** Im Gespraech liegt ein fertiger Rechercheprompt vor (z. B. aus research-prompt-forge, Option A). Fuehre die Recherche aus und baue daraus das Pruefdokument.
- **Modus T (Text pruefen):** Der Nutzer gibt einen vorhandenen Text (eingefuegt oder hochgeladen), z. B. eine Vorlage, einen Bericht oder die Ausgabe eines anderen KI-Werkzeugs. Zerlege ihn in belegpflichtige Aussagen, suche und pruefe die Quellen. Den Text selbst inhaltlich nicht umschreiben, nur Marker setzen.

Ist unklar, welcher Modus gemeint ist, frage genau das.

## Schritt 2 — Datenschutz-Vorpruefung (vor jeder Verarbeitung)

Pruefe den Prompt bzw. Text auf personenbezogene oder sensible Daten (Namen von Buerger:innen, Aktenzeichen mit Personenbezug, Adressen, Gesundheitsdaten, interne Verschlusssachen).

- Wenn solche Daten enthalten sind: nicht weiterarbeiten. Weise kurz darauf hin und bitte darum, den Text zu anonymisieren oder die Stellen zu entfernen. Erst danach fortfahren.
- Keine Hinweise gefunden: ohne Kommentar weiter.

## Schritt 3 — Rueckfragen (nur falls nicht schon klar, je eine Frage)

1. Zitierweise fuer das Verzeichnis?
   - Standard (empfohlen fuer Verwaltung): Fundstellenverzeichnis — Herausgeber/Autor, Titel, Datum, Medium/Stelle, URL, Abrufdatum
   - APA 7 (fuer wissenschaftliche Arbeiten)
   - Andere Vorgabe des Hauses
2. Nur in Modus T: Bis zu welchem Stand sollen Quellen gelten (Stichtag), falls relevant?

## Schritt 4 — Recherche bzw. Quellensuche

Regeln fuer jede Quelle:

- Nutze nur Quellen, die du in dieser Sitzung tatsaechlich aufgerufen hast. Erfinde niemals URLs, Autoren, Daten oder Zitate.
- Rangfolge: offizielle Stellen/Primaerquellen -> Wissenschaft -> anerkannte Fachmedien -> sonstige (nur ergaenzend, klar markiert).
- Kritische Aussagen (Zahlen, Fristen, Rechtslage, Zustaendigkeiten): moeglichst zwei unabhaengige Quellen.
- Bewerte jede Quelle auf drei Ebenen:
  1. **Existenz:** Gibt es die Quelle, fuehrt der Link zum genannten Dokument?
  2. **Zuordnung:** Steht die Aussage dort?
  3. **Tragfaehigkeit:** Traegt die Quelle die Aussage in dieser Staerke?
- Wird keine belastbare Quelle gefunden: so benennen, nicht ueberbruecken.

## Schritt 5 — Pruefdokument in Claude Docs erstellen

Lege ein Doc an. Titel: "Pruefdokument: [Thema]". Vier Tabs in dieser Reihenfolge:

### Tab 1 "Ergebnis"

- Modus R: der Recherchebericht im gewuenschten Format.
- Modus T: der Originaltext, unveraendert.
- Hinter jede belegpflichtige Aussage einen Marker [Q1], [Q2], ... setzen. Gleiche Nummer = gleiche Zeile in Tab 2.
- Oben ein Hinweis in einer Zeile: "Entwurf — Quellenpruefung in Tab 'Quellenpruefung' noch offen."

### Tab 2 "Quellenpruefung"

Einleitungssatz: "Belege zu den [Q]-Markern in Tab 'Ergebnis'. Quellen abgerufen am [Datum]."
Darunter eine Tabelle, eine Zeile pro Aussage:

| Spalte | Inhalt |
|---|---|
| Nr. | Q1, Q2, ... |
| Aussage | kurz zusammengefasst |
| Quelle | Name als Link; Quellentyp in Klammern (Primaer / Wissenschaft / Fachmedium / Sonstige) |
| Fundstelle | Abschnitt/Seite und ein kurzes woertliches Zitat (hoechstens ein Satz) |
| KI-Einschaetzung | Vorschlag: bestaetigt / eingeschraenkt / widerlegt / keine Quelle gefunden — plus welche Pruefebene betroffen ist |
| Hinweise | was fuer die Pruefung wichtig ist: Abweichungen, nur eine Quelle, Sekundaerquelle statt Primaerquelle, Datum unklar |
| Status (Mensch) | immer "offen" — wird nur von der pruefenden Person geaendert |
| Notizen | leer lassen |

Wenn moeglich, "KI-Einschaetzung" und "Status (Mensch)" als Auswahlfeld anlegen; sonst als Text.
Setze "Status (Mensch)" niemals selbst auf etwas anderes als "offen", auch wenn die KI-Einschaetzung "bestaetigt" lautet.

### Tab 3 "Quellenverzeichnis"

- In der gewaehlten Zitierweise, alphabetisch nach Autor bzw. Herausgeber.
- Angaben von der Originalseite uebernehmen. Fehlt eine Angabe, die Luecke markieren ("o. D." = ohne Datum, "o. V." = ohne Verfasser) statt sie zu ergaenzen.
- Bei wissenschaftlichen Artikeln den DOI-Link angeben.
- Nur Quellen aufnehmen, die in Tab 2 vorkommen.

### Tab 4 "Dokumentation"

Fuer Nachvollziehbarkeit und Dokumentationspflicht:

- Datum der Erstellung
- Werkzeug: Claude (claude.ai), Modell falls bekannt
- Modus (R oder T) und der verwendete Rechercheprompt bzw. Herkunft des Textes
- DSGVO: Ergebnis der Vorpruefung aus Schritt 2 (z. B. "keine personenbezogenen Daten verarbeitet")
- EU AI Act: Einsatzzweck, Hinweis "KI-gestuetzter Entwurf, menschliche Pruefung erforderlich"
- Offene Punkte: Anzahl Aussagen mit "eingeschraenkt", "widerlegt" oder "keine Quelle gefunden"
- Felder zum Ausfuellen (leer lassen): Geprueft von | Datum | Freigabe ja/nein | Bemerkung

## Schritt 6 — Abschluss im Chat

Kurz und ohne den Inhalt des Dokuments zu wiederholen:

1. Ein Satz zum Ergebnis, z. B. "12 Aussagen, davon 8 von der KI als bestaetigt eingeschaetzt, 3 eingeschraenkt, 1 ohne Quelle."
2. Die drei Pruefschritte fuer den Menschen:
   - Jeden Link selbst oeffnen (Existenz)
   - Die Fundstelle im Original nachlesen (Zuordnung)
   - Beurteilen, ob die Aussage so stark formuliert sein darf (Tragfaehigkeit) und dann "Status (Mensch)" setzen
3. Den Hinweis, dass Aussagen mit "widerlegt" oder "keine Quelle gefunden" vor einer Weitergabe angepasst oder gestrichen werden muessen.

## Fallback ohne Claude Docs

Falls kein Doc angelegt werden kann (z. B. Funktion abgeschaltet): Gib dieselbe Struktur im Chat aus, mit den Ueberschriften "Tab 1 — Ergebnis", "Tab 2 — Quellenpruefung" (als Tabelle), "Tab 3 — Quellenverzeichnis", "Tab 4 — Dokumentation". Weise in einem Satz darauf hin, dass unter Einstellungen -> Faehigkeiten "Dateien erstellen und bearbeiten" eingeschaltet sein muss, damit ein Doc entsteht.

## No-Gos

- Keine erfundenen Quellen, Links, Zitate oder Daten.
- Kein Setzen von "Status (Mensch)" durch die KI.
- Keine langen woertlichen Uebernahmen aus Quellen; hoechstens ein kurzer Satz pro Fundstelle.
- Keine Verarbeitung personenbezogener Daten ohne vorherige Anonymisierung.
- Im Modus T den Originaltext nicht inhaltlich veraendern.
